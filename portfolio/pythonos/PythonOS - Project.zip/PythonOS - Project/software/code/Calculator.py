import tkinter as tk
from math import sin, cos, tan, asin, acos, atan, sinh, cosh, tanh, log, log10, sqrt, pi, exp

class AdvancedCalculator(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("Advanced Scientific Calculator")
        self.geometry("400x600")

        self.result_var = tk.StringVar()
        self.result_var.set("0")
        icon_image = tk.PhotoImage(file="images/Calculator.png")
        self.iconphoto(True, icon_image)
        self.create_widgets()

    def create_widgets(self):
        # Entry widget to display the result
        entry = tk.Entry(self, textvariable=self.result_var, font=('Arial', 20), bd=10, relief=tk.SOLID, justify=tk.RIGHT, state="readonly")
        entry.grid(row=0, column=0, columnspan=4, sticky="nsew")

        # Buttons
        buttons = [
            ('7', 1, 0, {}), ('8', 1, 1, {}), ('9', 1, 2, {'bg': 'white'}), ('/', 1, 3, {}),
            ('4', 2, 0, {}), ('5', 2, 1, {}), ('6', 2, 2, {}), ('*', 2, 3, {}),
            ('1', 3, 0, {}), ('2', 3, 1, {}), ('3', 3, 2, {}), ('-', 3, 3, {}),
            ('0', 4, 0, {}), ('.', 4, 1, {}), ('=', 4, 2, {'bg': 'blue'}), ('+', 4, 3, {}),
            ('√', 5, 0, {}), ('(', 5, 1, {}), (')', 5, 2, {}), ('log', 5, 3, {}),
            ('sin', 6, 0, {}), ('cos', 6, 1, {}), ('tan', 6, 2, {}), ('exp', 6, 3, {}),
            ('sinh', 7, 0, {}), ('cosh', 7, 1, {}), ('tanh', 7, 2, {}), ('π', 7, 3, {'bg': 'white'}), ('C', 7, 4, {'bg': 'white'})
        ]

        for (text, row, column, options) in buttons:
            button_args = {'text': text, 'font': ('Arial', 16), 'padx': 20, 'pady': 20, 'command': lambda t=text: self.on_button_click(t)}
            
            # Update button_args with options if provided
            if options:
                button_args.update(options)

            button = tk.Button(self, **button_args)
            button.grid(row=row, column=column, sticky="nsew")

        # Configure grid weights to make the buttons expandable
        for i in range(8):
            self.grid_rowconfigure(i, weight=1)
            self.grid_columnconfigure(i, weight=1)

    def on_button_click(self, button_text):
        current_text = self.result_var.get()

        if button_text == '=':
            try:
                result = self.evaluate_expression(current_text)
                self.result_var.set(result)
            except Exception as e:
                self.result_var.set("Error")
        elif button_text == 'C':
            self.result_var.set("0")
        else:
            # Append the button text to the current entry text
            if current_text == "0":
                self.result_var.set(button_text)
            else:
                self.result_var.set(current_text + button_text)

    def evaluate_expression(self, expression):
        try:
            result = self.parse_expression(expression)
            return str(result)
        except Exception as e:
            raise ValueError("Invalid expression")

    def parse_expression(self, expression):
        # Custom expression parser
        expression = expression.replace('^', '**')  # Convert ^ to ** for exponentiation
        expression = expression.replace('π', str(pi))  # Replace π with the mathematical constant

        # List of allowed symbols and functions
        allowed_symbols = set('1234567890.+-*/()')
        allowed_functions = {'sin', 'cos', 'tan', 'exp', 'sinh', 'cosh', 'tanh', 'log', 'sqrt'}

        # Check if all characters are allowed
        if all(char in allowed_symbols or char.isalpha() and char.islower() for char in expression):
            # Replace allowed functions with their respective math module functions
            for func in allowed_functions:
                expression = expression.replace(func, 'self.' + func)

            # Evaluate the modified expression
            result = eval(expression)
            return result
        else:
            raise ValueError("Invalid expression")

    def sin(self, x):
        return sin(x)

    def cos(self, x):
        return cos(x)

    def tan(self, x):
        return tan(x)

    def exp(self, x):
        return exp(x)

    def sinh(self, x):
        return sinh(x)

    def cosh(self, x):
        return cosh(x)

    def tanh(self, x):
        return tanh(x)

    def log(self, x):
        return log(x)

    def sqrt(self, x):
        return sqrt(x)


if __name__ == "__main__":
    advanced_calculator = AdvancedCalculator()
    advanced_calculator.mainloop()
