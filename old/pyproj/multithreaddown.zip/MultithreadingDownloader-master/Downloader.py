
import multiprocessing
import sys
import threading
import time
from contextlib import closing

import requests
import requests.adapters


class Downloader:

    def __init__(self,
                 threads_num=20,
                 chunk_size=1024 * 128,
                 timeout=0,
                 enable_log=True
                 ):
        self.threads_num = threads_num
        self.chunk_size = chunk_size
        self.timeout = timeout if timeout != 0 else threads_num  # 超时时间正比于线程数

        self.__content_size = 0
        self.__file_lock = threading.Lock()
        self.__threads_status = {}
        self.__crash_event = threading.Event()
        self.__msg_queue = multiprocessing.Queue()

        self.__enable_log = enable_log
        self.__logger = Logger(msgq=self.__msg_queue) if enable_log else None

        requests.adapters.DEFAULT_RETRIES = 2

    def __establish_connect(self, url):
        print("ESTABLISHING......")
        hdr = requests.head(url).headers
        self.__content_size = int(hdr["Content-Length"])
        print("ESTABLISH SUCCESS!FILE SIZE：{}B".format(self.__content_size))

    def __page_dispatcher(self):
        basic_page_size = self.__content_size // self.threads_num
        start_pos = 0
        while start_pos + basic_page_size < self.__content_size:
            yield {
                'start_pos': start_pos,
                'end_pos': start_pos + basic_page_size
            }
            start_pos += basic_page_size + 1

        yield {
            'start_pos': start_pos,
            'end_pos': self.__content_size - 1
        }

    def __download(self, url, file, page):
        headers = {
            "Range": "bytes={}-{}".format(page["start_pos"], page["end_pos"])
        }
        thread_name = threading.current_thread().name
        self.__threads_status[thread_name] = {
            "page_size": page["end_pos"] - page["start_pos"],
            "page": page,
            "status": 0,
        }
        try:
            with closing(requests.get(
                    url=url,
                    headers=headers,
                    stream=True,
                    timeout=self.timeout
            )) as response:
                for data in response.iter_content(chunk_size=self.chunk_size):
                    with self.__file_lock:
                        file.seek(page["start_pos"])
                        file.write(data)
                    page["start_pos"] += len(data)
                    self.__threads_status[thread_name]["page"] = page
                    if self.__enable_log:
                        self.__msg_queue.put(self.__threads_status)

        except requests.RequestException as exception:
            print("XXX From {}: ".format(exception), file=sys.stderr)
            self.__threads_status[thread_name]["status"] = 1
            if self.__enable_log:
                self.__msg_queue.put(self.__threads_status)
            self.__crash_event.set()

    def __run(self, url, target_file, urlhandler):

        thread_list = []
        self.__establish_connect(url)
        self.__threads_status["url"] = url
        self.__threads_status["target_file"] = target_file
        self.__threads_status["content_size"] = self.__content_size
        self.__crash_event.clear()
        url = urlhandler(url)
        with open(target_file, "wb+") as file:
            for page in self.__page_dispatcher():
                thd = threading.Thread(
                    target=self.__download, args=(url, file, page)
                )
                thd.start()
                thread_list.append(thd)
            for thd in thread_list:
                thd.join()
        self.__threads_status = {}
        if self.__crash_event.is_set():
            raise Exception("UNKNOWN ERROR")

    def start(self, url, target_file, urlhandler=lambda u: u):
        start_time = time.time()
        if self.__enable_log:
            self.__logger.start()
            self.__run(url, target_file, urlhandler)
            self.__logger.join(0.5)
        else:
            self.__run(url, target_file, urlhandler)

        span = time.time() - start_time
        print("COMPLETE,TIME:{}s".format(span - 0.5))


class Logger(multiprocessing.Process):
    def __init__(self, msgq):
        multiprocessing.Process.__init__(self, daemon=True)
        self.__threads_status = {}
        self.__msg_queue = msgq

    def __log_metainfo(self):

        print("INFO:\nURL: {}\nFILE_NAME:{}\nFILE_SIZE:{}KB".format(
            self.__threads_status["url"],
            self.__threads_status["target_file"],
            self.__threads_status["content_size"] / 1024
        ))

    def __log_threadinfo(self):
        downloaded_size = 0
        for thread_name, thread_status in self.__threads_status.items():
            if thread_name not in ("url", "target_file", "content_size"):
                page_size = thread_status["page_size"]
                page = thread_status["page"]
                thread_downloaded_size = page_size - \
                                         (page["end_pos"] - page["start_pos"])
                downloaded_size += thread_downloaded_size
                self.__print_thread_status(
                    thread_name, thread_status["status"], page_size,
                    page, thread_downloaded_size
                )
        self.__print_generalinfo(downloaded_size)

    def __print_thread_status(self, thread_name, status, page_size, page, thread_downloaded_size):
        if status == 0:
            if page["start_pos"] < page["end_pos"]:
                print("|- {}  Downloaded: {}KB / Chunk: {}KB".format(
                    thread_name,
                    thread_downloaded_size / 1024,
                    page_size / 1024,
                ))
            else:
                print("|=> {} Finished.".format(thread_name))
        elif status == 1:
            print("|XXX {} Crushed.".format(
                thread_name
            ), file=sys.stderr)

    def __print_generalinfo(self, downloaded_size):


        print("|__DOWNLOADED: {}KB / Total: {}KB".format(
            downloaded_size / 1024,
            self.__threads_status["content_size"] / 1024
        ))

    def run(self):
        while True:
            if self.__msg_queue.qsize() != 0:
                print("\033c")
                self.__threads_status = self.__msg_queue.get()
                self.__log_metainfo()
                self.__log_threadinfo()


if __name__ == '__main__':
    DOWNLOADER = Downloader(
        threads_num=10
    )
    DOWNLOADER.start(
        url="http://leibniz.minatoms.com/massive_file/Stick-Figure-Animation.part04.rar",
        target_file="stickanimation04.rar",
    )
